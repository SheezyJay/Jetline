# Pipelinenode

Pipelinenode is a Python package for managing pipeline nodes.

## Installation

You can install Pipelinenode using pip:

